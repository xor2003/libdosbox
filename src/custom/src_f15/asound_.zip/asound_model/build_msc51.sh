#!/usr/bin/env bash
set -euo pipefail

KVD="/home/xor/kvikdos/kvikdos"
MSC_BIN="/home/xor/inertia_player/dos_compilers/Microsoft C v5.1/bin"
MASM_BIN="/home/xor/inertia_player/dos_compilers/Microsoft MASM v5/BIN"
INCLUDE_DIR="/home/xor/inertia_player/dos_compilers/Microsoft C v5.1/INCLUDE"
ROOT="$(cd "$(dirname "$0")" && pwd)"
WD="/tmp/AS15MS"

mkdir -p "${WD}"
rm -f "${WD}"/*.C "${WD}"/*.H "${WD}"/*.ASM "${WD}"/*.EXE "${WD}"/*.OBJ "${WD}"/*.MAP "${WD}"/*.LST

cp -f "${ROOT}/asound_model.c" "${WD}/AM1.C"
cp -f "${ROOT}/asound_model.h" "${WD}/AM1.H"
cp -f "${ROOT}/asopl.c" "${WD}/AOPL.C"
cp -f "${ROOT}/asopl.h" "${WD}/AOPL.H"
cp -f "${ROOT}/asopl_inst.inc" "${WD}/AOPL_I.INC"
cp -f "${ROOT}/asdrv51.c" "${WD}/AD1.C"
cp -f "${ROOT}/asdrv51.asm" "${WD}/ASDRV.ASM"

sed -i -e 's/asound_model.h/AM1.H/g' "${WD}/AM1.C" "${WD}/AD1.C"
sed -i \
  -e 's/"asound_model.h"/"AM1.H"/g' \
  -e 's/"asopl.h"/"AOPL.H"/g' \
  -e 's/"asopl_inst.inc"/"AOPL_I.INC"/g' \
  "${WD}/AOPL.C" "${WD}/AD1.C" "${WD}/AOPL.H"

cp -f "${WD}/AM1.H" "${WD}/AM.H"
cp -f "${WD}/AM1.C" "${WD}/AM.C"
cp -f "${WD}/AD1.C" "${WD}/AD.C"

"${KVD}" --mount="b:${MSC_BIN}/" \
  --mount="c:${WD}/" \
  --mount="f:${INCLUDE_DIR}/" \
  B:\CL.EXE /c /Zl /Gs /W3 /G2 /AS /FoC:\AM.OBJ /I F:\ C:\AM.C
"${KVD}" --mount="b:${MSC_BIN}/" \
  --mount="c:${WD}/" \
  --mount="f:${INCLUDE_DIR}/" \
  B:\CL.EXE /c /Zl /Gs /W3 /G2 /AS /FoC:\AOPL.OBJ /I F:\ C:\AOPL.C
"${KVD}" --mount="b:${MSC_BIN}/" \
  --mount="c:${WD}/" \
  --mount="f:${INCLUDE_DIR}/" \
  B:\CL.EXE /c /Zl /Gs /W3 /G2 /AS /FoC:\AD.OBJ /I F:\ C:\AD.C
"${KVD}" --mount="b:${MASM_BIN}/" \
  --mount="c:${WD}/" \
  B:\MASM.EXE C:\ASDRV.ASM,C:\ASDRV.OBJ,C:\ASDRV.LST,NUL\;

"${KVD}" --mount="b:${MSC_BIN}/" --mount="c:${WD}/" B:\LINK.EXE <<'EOF'
C:\ASDRV.OBJ+C:\AM.OBJ+C:\AOPL.OBJ+C:\AD.OBJ
C:\ASDRV.EXE
C:\ASDRV.MAP
;
EOF

python3 - "${WD}/ASDRV.EXE" <<'PY'
from pathlib import Path
import struct
import sys

path = Path(sys.argv[1])
image = bytearray(path.read_bytes())
header_size = struct.unpack_from("<H", image, 8)[0] * 16
payload_size = len(image) - header_size
struct.pack_into("<H", image, header_size + 0x1E, payload_size)
path.write_bytes(image)
print(f"patched payload size to 0x{payload_size:04X}")
PY

cp -f "${WD}/ASDRV.EXE" "${ROOT}/asound_msc51.exe"

ls -la "${WD}" | sed -n '1,120p'
echo "wrote: ${ROOT}/asound_msc51.exe"
