# ASOUND host model

This directory contains a small C model of selected ASOUND behavior. It is not a replacement driver yet; it is a deterministic test harness for the data structures and bytecode semantics decoded in `../asound_rebuild/asound_rebuild.asm`.

The model now exposes **compatibility entry points** for the original ASOUND/F14 ABI:

- `sound_driver_*` functions with the same argument shapes as the reconstructed ASM entrytable.
- `audio_slot_64..audio_slot_6d` and `audio_jump_64..audio_jump_6d` aliases.

The modern C model now has a paired OPL shadow backend in `asopl.[ch]`. It can translate the decoded bytecode/event flow into YM3812 register state, and the MS C 5.1 DOS wrapper now flushes that shadow state to ports `388h/389h` on timer ticks.

Two compatibility details are now modeled directly from `asound_rebuild.asm`:

- `sound_driver_play_intro()` starts the six intro streams instead of acting as a no-op.
- `sound_driver_play_sample()` accepts both logical sample ids (`0`, `1`, `2`) and the overlay ABI's byte offsets (`0`, `2`, `4`).

The MS C 5.1 DOS build now also exposes the original overlay-facing ABI shape:

- the payload starts with the ASOUND-style metadata block,
- the ten exported entries are far-call thunks with `retf`,
- and the entry table points to those thunks using overlay byte offsets.

This DOS artifact is interface-compatible, not byte-identical. The byte-identical rebuild remains `../asound_rebuild/asound_rebuild.asm`.

## SDL Rewrite Path

If you are seeing ASOUND and AdLib for the first time and want to replace this
driver with SDL audio, read the files in this order:

1. `asound_model.h`
2. `asound_model.c`
3. `asopl.h` / `asopl.c`
4. `asdrv51.c`
5. `asdrv51.asm`
6. `../asound_rebuild/asound_rebuild.asm`

Recommended mental model:

- `asound_model.*` is the portable behavior layer.
- `asopl.*` is a compatibility backend that expresses that behavior as OPL/YM3812 register state.
- `asdrv51.*` is DOS-specific glue for the historical overlay ABI and hardware timing.

For an SDL rewrite, the usual plan is:

1. Keep the meaning of `audio_slot_64..audio_slot_6d`.
2. Keep the timer-tick driven stream/sample scheduling semantics.
3. Replace direct OPL register writes with your own backend:
   - SDL mixer playback
   - software OPL emulator
   - MIDI/synth translation
   - pre-rendered PCM
4. Treat the DOS-only pieces as reference, not as architecture:
   - `388h/389h` port writes
   - PIT/PIC/PPI handling
   - blocking sample busy-waits
   - far thunks / `retf` ABI wrappers

If you only need modern audio and not binary compatibility, start from
`asound_driver_tick_and_dispatch()` and build your backend around emitted
events instead of around the DOS wrapper.

Current behavior split:

- Stream-driven AdLib voices now load original instrument records, set note/fnum, key on/off, and apply per-tick pitch-slide updates through the C OPL backend.
- The exported overlay ABI is still preserved through the far thunk entry table.
- Sample playback (`audio_slot_6d`) now has a DOS-side blocking PCM-to-OPL path in `asdrv51.c`, using the caller-provided sample segment plus the decoded sample ranges.
- Drone/noise update entry points are still only partially modeled compared to the original ASM.

## Callback API

`asound_driver_tick_and_dispatch()` is available for modern C host integration. It:

- ticks the driver into a caller-provided event buffer,
- returns the number of events emitted,
- and optionally forwards each event to a callback.

```c
void callback(void* user, AsoundEventType type, AsoundU8 voice,
              AsoundU16 a, AsoundU16 b);

AsoundEvent events[32];
size_t event_count = 0;
asound_driver_tick_and_dispatch(&driver, events, 32, &event_count,
                               callback, NULL);
```

## Goals

- Keep `../asound_rebuild/asound_rebuild.asm` as the byte-identical oracle.
- Model ASOUND behavior as portable C before replacing audio output in the modern port.
- Log semantic events instead of producing audio directly.
- Keep the core close to C89 so it can later be ported to older DOS compilers if needed.

## Current Coverage

- `SoundStreamState`, matching the 20-byte runtime stream state in ASOUND.
- `SampleRange`, matching the `sample_variant_ranges` table.
- `asound_stream_pitch_slide_1222e`, matching the short bytecode stream formerly labeled `unk_1222E`.
- Named C arrays for the currently decoded short dispatch streams.
- `AsoundDriver`, with six stream states and byte-offset dispatch matching the understood entries in ASOUND's `audio_sound_dispatch_table`.
- Intro/release stream tables `adlib_intro_voice0..5` and `adlib_release_voice0..5`, exposed as named C arrays.
- Basic bytecode commands: `F8`, `F9`, `FA`, `FB`, `FC`, `FD`, `FE`, `FF`, plus event/tick pairs and `00,00` termination.
- Event log output for instrument, volume, pitch delta, key-off gap, key-on, key-off, stream end, and sample ranges.
- `asopl.[ch]`, a portable OPL shadow backend loaded from the original ASOUND instrument table.

The two random dispatch entries at byte offsets `00h` and `02h` are now modeled as seed-indexed random stream selectors.

## Runtime Driver Wrapper

`asound_runtime.[ch]` adds a compact API intended for modern host integration:

- initialize/reset/shutdown an `AsoundRuntime`
- dispatch sound offsets through `asound_runtime_dispatch_sound()`
- tick and retrieve event batches
- dispatch events to an output callback for backends
- query sample variant ranges for sample-player integration

```c
AsoundRuntime runtime;
AsoundEvent events[32];
size_t event_count = 0;

asound_runtime_init(&runtime, 0x7d9d, callback, NULL);
asound_runtime_dispatch_sound(&runtime, 0x0au);
asound_runtime_tick_and_dispatch(&runtime, events, 32, &event_count);
```

## Run Tests

```bash
src/custom/src_f15/asound_model/run_tests.sh
```

The test binaries are built in `/tmp/asound_model_tests` (default compiler) and `/tmp/asound_model_tests_clang` (if `clang` exists), and are independent from the main DOSBox test suite.

## MS C 5.1 Overlay Build

Run:

```bash
src/custom/src_f15/asound_model/build_msc51.sh
```

This produces `asound_msc51.exe`, which is a DOS EXE with:

- ASOUND-style payload header at load-module offset `0`,
- patched payload size in the exported metadata word,
- and far thunks for `audio_slot_64..audio_slot_6d`.
- The timer entry now drives real OPL register writes for the decoded stream voices.
- The sample entry now runs a direct DOS playback loop that maps sample bytes onto OPL register `43h`.

## DOS Harness

Run:

```bash
src/custom/src_f15/asound_model/run_h51.sh [setup|sample0|sample1|sample2|timer|noise]
```

This builds a tiny DOS test program around the same driver objects and runs one selected phase under `kvikdos`.

Current harness limits:

- it extracts `0x7d9e` bytes from segment `17C5:` of `../libdosbox-0.5x/f/F.EXE`,
- `setup`, `timer`, and `noise` finish quickly and are useful for short host-side traces,
- `sample0..2` enter the blocking sample path and are currently best used as trace producers that you stop externally after enough data is captured,
- it does not yet compare audible output or register traces against the original ASOUND driver.

For host-side OPL tracing with `kvikdos`:

```bash
KVIKDOS_IO_TRACE=/tmp/AS15TS_setup/OPL.TRC \
  src/custom/src_f15/asound_model/run_h51.sh setup
```

The current `kvikdos` trace record format is 4 bytes per transfer:

- byte 0: `'O'` or `'I'`
- byte 1: port low byte
- byte 2: port high byte
- byte 3: transferred value

The short-path build directory is `/tmp/AS15MS`, and the directly runnable DOS artifact there is `ASDRV.EXE`.

For a quick modern-C smoke test that prints semantic events from the model:

```bash
src/custom/src_f15/asound_model/run_demo.sh <setup> <dispatch_offset> <ticks>
```

Example:

```bash
src/custom/src_f15/asound_model/run_demo.sh 0x7d9d 0x0a 24
```

## Next Steps

- Build an original-ASOUND trace harness for the same per-phase sequence and diff against the rebuilt-driver traces.
- Compare the harness-fed real `17C5:` sample playback path against original ASOUND audible behavior.
- Port the drone/noise control path (`audio_slot_68..6c`) onto the same backend instead of leaving it mostly semantic.
- Compare C-backend OPL register traces against DOSBox traces of the original ASM driver.
- Fold the remaining long intro/stream tables into the named C data set where it helps maintenance.
