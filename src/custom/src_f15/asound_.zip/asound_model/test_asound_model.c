#include "asound_model.h"

#include <assert.h>
#include <stdio.h>

static void expect_event(const AsoundEventLog* log, size_t index,
                         AsoundEventType type, AsoundU8 voice, AsoundU16 a,
                         AsoundU16 b)
{
	assert(index < log->count);
	assert(log->events[index].type == type);
	assert(log->events[index].voice == voice);
	assert(log->events[index].a == a);
	assert(log->events[index].b == b);
}

typedef struct CallbackCollector {
	AsoundEvent events[16];
	size_t count;
} CallbackCollector;

static void callback_collector(void* user, AsoundEventType type, AsoundU8 voice,
                               AsoundU16 a, AsoundU16 b)
{
	CallbackCollector* collector = (CallbackCollector*)user;
	if (collector->count <
	    (size_t)(sizeof(collector->events) / sizeof(collector->events[0]))) {
		collector->events[collector->count].type  = type;
		collector->events[collector->count].voice = voice;
		collector->events[collector->count].a     = a;
		collector->events[collector->count].b     = b;
		++collector->count;
	}
}

static void test_sample_ranges(void)
{
	SampleRange r;
	assert(asound_sample_variant_max_index(0x0000u) == 0);
	assert(asound_sample_variant_max_index(0x6a19u) == 0);
	assert(asound_sample_variant_max_index(0x6a1au) == 1);
	assert(asound_sample_variant_max_index(0x7d9cu) == 1);
	assert(asound_sample_variant_max_index(0x7d9du) == 2);
	assert(asound_sample_variant_next(0, 0) == 0);
	assert(asound_sample_variant_next(0, 1) == 1);
	assert(asound_sample_variant_next(1, 1) == 0);
	assert(asound_sample_variant_next(1, 2) == 2);
	assert(asound_sample_variant_next(2, 2) == 0);
	r = asound_sample_variant_range(0);
	assert(r.start == 0x4797u && r.end == 0x5c92u);
	r = asound_sample_variant_range(1);
	assert(r.start == 0x5c93u && r.end == 0x6a1au);
	r = asound_sample_variant_range(2);
	assert(r.start == 0x6a1bu && r.end == 0x7d9du);
}

static void test_pitch_slide_stream_prefix(void)
{
	AsoundEvent events[16];
	AsoundEventLog log;
	SoundStreamState state;

	asound_log_init(&log, events, 16);
	asound_stream_init(&state, asound_stream_pitch_slide_1222e);
	asound_stream_step(&state, 3, &log);

	assert(log.count == 5);
	expect_event(&log, 0, ASOUND_EVENT_INSTRUMENT, 3, 0x08u, 0);
	expect_event(&log, 1, ASOUND_EVENT_VOLUME, 3, 0x2cu, 0);
	expect_event(&log, 2, ASOUND_EVENT_KEYOFF_GAP, 3, 0x08u, 0);
	expect_event(&log, 3, ASOUND_EVENT_PITCH_DELTA, 3, 0x11u, 0);
	expect_event(&log, 4, ASOUND_EVENT_KEY_ON, 3, 0x44u, 0x14u);
	assert(state.ticks_left == 0x14u);
	assert(state.keyoff_ticks_left == 0x0cu);
}

static void test_pitch_slide_stream_finishes(void)
{
	AsoundEvent events[32];
	AsoundEventLog log;
	SoundStreamState state;
	int i;

	asound_log_init(&log, events, 32);
	asound_stream_init(&state, asound_stream_pitch_slide_1222e);
	asound_stream_step(&state, 3, &log);
	for (i = 0; i < 20; ++i) {
		asound_stream_step(&state, 3, &log);
	}

	assert(log.count >= 9);
	expect_event(&log, 5, ASOUND_EVENT_KEY_OFF, 3, 0, 0);
	expect_event(&log, 6, ASOUND_EVENT_PITCH_DELTA, 3, 0, 0);
	expect_event(&log, 7, ASOUND_EVENT_KEY_OFF, 3, 0, 0);
	expect_event(&log, 8, ASOUND_EVENT_STREAM_END, 3, 0, 0);
	assert(state.stream_ptr == 0);
}

static void test_volume_fade_ticks_emit_runtime_volume(void)
{
	static const AsoundU8 fade_stream[] = {
	        0xf9u, 0x10u, 0xf8u, 0x02u, 0xffu, 0x05u, 0x03u, 0x00u, 0x00u,
	};
	AsoundEvent events[16];
	AsoundEventLog log;
	SoundStreamState state;

	asound_log_init(&log, events, 16);
	asound_stream_init(&state, fade_stream);
	asound_stream_step(&state, 0, &log);

	assert(log.count == 4);
	expect_event(&log, 0, ASOUND_EVENT_VOLUME, 0, 0x10u, 0u);
	expect_event(&log, 1, ASOUND_EVENT_VOLUME, 0, 0x02u, 0xffu);
	expect_event(&log, 2, ASOUND_EVENT_KEY_ON, 0, 0x05u, 0x03u);
	expect_event(&log, 3, ASOUND_EVENT_VOLUME, 0, 0x11u, 0u);
	assert(state.volume == 0x11u);
	assert(state.volume_fade_ticks_left == 0x02u);
}

static void test_driver_dispatch_pitch_slide(void)
{
	AsoundEvent events[16];
	AsoundEventLog log;
	AsoundDriver driver;

	asound_log_init(&log, events, 16);
	asound_driver_init(&driver, 0x7d9du);

	assert(asound_driver_dispatch_sound(&driver, 0x0au));
	assert(driver.streams[3].stream_ptr == asound_stream_pitch_slide_1222e);

	asound_driver_tick(&driver, &log);
	assert(log.count == 5);
	expect_event(&log, 0, ASOUND_EVENT_INSTRUMENT, 3, 0x08u, 0);
	expect_event(&log, 4, ASOUND_EVENT_KEY_ON, 3, 0x44u, 0x14u);
}

static void test_driver_dispatch_dual_stream(void)
{
	AsoundEvent events[16];
	AsoundEventLog log;
	AsoundDriver driver;

	asound_log_init(&log, events, 16);
	asound_driver_init(&driver, 0);

	assert(asound_driver_dispatch_sound(&driver, 0x20u));
	assert(driver.streams[1].stream_ptr == asound_stream_122ac);
	assert(driver.streams[3].stream_ptr == asound_stream_122b4);

	asound_driver_tick(&driver, &log);
	assert(log.count == 6);
	expect_event(&log, 0, ASOUND_EVENT_INSTRUMENT, 1, 0x1bu, 0);
	expect_event(&log, 2, ASOUND_EVENT_KEY_ON, 1, 0x04u, 0x3cu);
	expect_event(&log, 3, ASOUND_EVENT_INSTRUMENT, 3, 0x1au, 0);
	expect_event(&log, 5, ASOUND_EVENT_KEY_ON, 3, 0x21u, 0x3cu);
}

static void test_driver_dispatch_random_streams(void)
{
	AsoundEvent events[16];
	AsoundEventLog log;
	AsoundDriver driver;

	asound_log_init(&log, events, 16);
	asound_driver_init(&driver, 0);

	driver.random_seed = 0x0000u;
	assert(asound_driver_dispatch_sound(&driver, 0x00u));
	assert(driver.streams[0].stream_ptr == asound_stream_r0v0_07c8);
	assert(driver.streams[0].ticks_left == 1u);
	asound_driver_tick(&driver, &log);
	expect_event(&log, 0, ASOUND_EVENT_INSTRUMENT, 0, 0x03u, 0);
	expect_event(&log, 1, ASOUND_EVENT_VOLUME, 0, 0x3fu, 0);
	expect_event(&log, 2, ASOUND_EVENT_KEY_ON, 0, 0x09u, 0x78u);

	asound_log_init(&log, events, 16);
	asound_driver_init(&driver, 0);
	driver.random_seed = 0x1234u;
	assert(asound_driver_dispatch_sound(&driver, 0x00u));
	assert(driver.streams[0].stream_ptr == asound_stream_r0v0_07e0);

	asound_log_init(&log, events, 16);
	asound_driver_init(&driver, 0);
	driver.random_seed = 0x0000u;
	assert(asound_driver_dispatch_sound(&driver, 0x02u));
	assert(driver.streams[2].stream_ptr == asound_stream_r2v2_07a8);
	asound_driver_tick(&driver, &log);
	expect_event(&log, 0, ASOUND_EVENT_INSTRUMENT, 2, 0x02u, 0);
	expect_event(&log, 1, ASOUND_EVENT_VOLUME, 2, 0x3eu, 0);
	expect_event(&log, 2, ASOUND_EVENT_KEY_ON, 2, 0x09u, 0x51u);
}

static void test_driver_dispatch_idle_guard(void)
{
	AsoundDriver driver;

	asound_driver_init(&driver, 0);
	assert(asound_driver_dispatch_sound(&driver, 0x14u));
	assert(driver.streams[4].stream_ptr == asound_stream_12274);
	driver.streams[4].stream_pos = 5;

	assert(asound_driver_dispatch_sound(&driver, 0x14u));
	assert(driver.streams[4].stream_pos == 5);
}

static void test_driver_dispatch_rejects_unknown_or_odd_offsets(void)
{
	AsoundDriver driver;

	asound_driver_init(&driver, 0);
	assert(!asound_driver_dispatch_sound(&driver, 0x01u));
	assert(!asound_driver_dispatch_sound(&driver, 0x24u));
	assert(!asound_driver_dispatch_sound(&driver, 0x23u));
}

static void test_driver_play_sample_events(void)
{
	AsoundEvent events[8];
	AsoundEventLog log;
	AsoundDriver driver;
	SampleRange r;

	asound_log_init(&log, events, 8);
	asound_driver_init(&driver, 0x7d9du);
	driver.sample_variant_index = 0;
	asound_driver_play_sample(&driver, 0x00u);
	asound_driver_tick(&driver, &log);
	expect_event(&log, 0, ASOUND_EVENT_SAMPLE_RANGE, 0, 0x0000u, 0x31f3u);

	asound_log_init(&log, events, 8);
	asound_driver_init(&driver, 0x7d9du);
	driver.sample_variant_index = 0;
	asound_driver_play_sample(&driver, 0x01u);
	r = asound_sample_variant_range(1u);
	asound_driver_tick(&driver, &log);
	expect_event(&log, 0, ASOUND_EVENT_SAMPLE_RANGE, 0, r.start, r.end);
	assert(driver.sample_variant_index == 1u);

	asound_log_init(&log, events, 8);
	asound_driver_init(&driver, 0x7d9du);
	asound_driver_play_sample(&driver, 0x02u);
	asound_driver_tick(&driver, &log);
	expect_event(&log, 0, ASOUND_EVENT_SAMPLE_RANGE, 0, 0x31f4u, 0x4796u);
}

static void test_driver_start_intro(void)
{
	AsoundEvent events[32];
	AsoundEventLog log;
	AsoundDriver driver;

	asound_log_init(&log, events, 32);
	asound_driver_init(&driver, 0x7d9du);
	asound_driver_start_intro(&driver);

	assert(driver.streams[0].stream_ptr == asound_intro_voice0);
	assert(driver.streams[5].stream_ptr == asound_intro_voice5);

	asound_driver_tick(&driver, &log);
	assert(log.count >= 18);
	expect_event(&log, 0, ASOUND_EVENT_INSTRUMENT, 0, 0x0eu, 0);
	expect_event(&log, 1, ASOUND_EVENT_VOLUME, 0, 0x26u, 0);
	expect_event(&log, 2, ASOUND_EVENT_KEYOFF_GAP, 0, 0x05u, 0);
	expect_event(&log, 3, ASOUND_EVENT_KEY_ON, 0, 0x45u, 0x0bu);
}

static void test_sound_driver_play_sample_accepts_overlay_offsets(void)
{
	audio_slot_64(0x7d9du, 0x11a3u);
	assert(sound_driver_play_sample(0x04u));
	assert(sound_driver_play_sample(0x02u));
	assert(sound_driver_play_sample(0x00u));
	assert(!sound_driver_play_sample(0x03u));
	audio_slot_65();
}

static void test_sound_driver_compat_wrappers(void)
{
	AsoundEvent events[16];
	AsoundEventLog log;

	asound_log_init(&log, events, 16);

	audio_slot_64(0x7d9du, 0x11a3u);
	assert(sound_driver_dispatch_sound(0x0au));
	assert(sound_driver_play_sample(0x00u));
	assert(sound_driver_play_sample(0x02u));
	assert(!sound_driver_play_sample(0xFFu));
	assert(audio_slot_66(0x00u) == 0 || audio_slot_66(0x00u) == 1);
	assert(audio_slot_6d(0x01u) == 1);
	assert(!audio_slot_6d(0xFFu));
	sound_driver_set_drone_pitch(0x2ABCu);
	sound_driver_enable_drone();
	sound_driver_disable_drone();
	sound_driver_play_intro();
	sound_driver_timer_tick();
	sound_driver_noise_tick();
	audio_slot_65();
	(void)events;
}

static void test_tick_and_dispatch_callbacks(void)
{
	AsoundEvent events[16];
	AsoundEventLog log;
	size_t event_count;
	CallbackCollector collector;
	AsoundDriver driver;

	asound_driver_init(&driver, 0x7d9du);
	assert(asound_driver_dispatch_sound(&driver, 0x0au));

	collector.count = 0;
	asound_driver_tick_and_dispatch(
	        &driver, events, 16, &event_count, callback_collector, &collector);
	asound_log_init(&log, events, 16);
	log.count = event_count;

	assert(event_count == collector.count);
	assert(event_count >= 5);
	expect_event(&log, 0, ASOUND_EVENT_INSTRUMENT, 3, 0x08u, 0u);
	assert(collector.events[0].type == ASOUND_EVENT_INSTRUMENT);
	assert(collector.events[0].voice == 3);
	assert(collector.events[0].a == 0x08u);
	assert(collector.events[0].b == 0u);
	assert(collector.events[4].type == ASOUND_EVENT_KEY_ON);
	assert(collector.events[4].voice == 3);
	assert(collector.events[4].a == 0x44u);
	assert(collector.events[4].b == 0x14u);
}

static void test_tick_and_dispatch_without_counter(void)
{
	AsoundEvent events[16];
	CallbackCollector collector;
	AsoundDriver driver;

	asound_driver_init(&driver, 0x7d9du);
	assert(asound_driver_dispatch_sound(&driver, 0x0au));

	collector.count = 0;
	asound_driver_tick_and_dispatch(
	        &driver, events, 16, 0, callback_collector, &collector);
	assert(collector.count >= 5);
}

static void test_tick_and_dispatch_without_buffer(void)
{
	CallbackCollector collector;
	AsoundDriver driver;

	asound_driver_init(&driver, 0x7d9du);
	assert(asound_driver_dispatch_sound(&driver, 0x0au));

	collector.count = 0;
	asound_driver_tick_and_dispatch(&driver, 0, 0, 0, callback_collector, &collector);
	assert(collector.count >= 5);
}

int main(void)
{
	test_sample_ranges();
	test_pitch_slide_stream_prefix();
	test_pitch_slide_stream_finishes();
	test_volume_fade_ticks_emit_runtime_volume();
	test_driver_dispatch_pitch_slide();
	test_driver_dispatch_dual_stream();
	test_driver_dispatch_random_streams();
	test_driver_dispatch_idle_guard();
	test_driver_dispatch_rejects_unknown_or_odd_offsets();
	test_driver_play_sample_events();
	test_driver_start_intro();
	test_sound_driver_play_sample_accepts_overlay_offsets();
	test_sound_driver_compat_wrappers();
	test_tick_and_dispatch_callbacks();
	test_tick_and_dispatch_without_counter();
	test_tick_and_dispatch_without_buffer();
	puts("asound_model tests passed");
	return 0;
}
